# College Kings 2 Translation Files

## Tutorials

### How to start translating a new part:
1. Fork the repository.
2. Clone the GitHub repository to your PC.
3. Find your language folder. If your language doesn't exist contact @KiloOscarSix to create a new translation folder.
4. Open a file and start translating.

### How add a newly translated part:
1. Push it to your forked repository.
2. Create a Pull Request to be reviewed and merged.

Have fun!

## Change Log
1.0: Created blank "francais" and "chinese"
